package com.marvin.holamundo.Model;

public class persona {
private String Nombre;
public String getNombre() {
	return Nombre;
}
public void setNombre(String nombre) {
	Nombre = nombre;
}
public String getApellido() {
	return Apellido;
}
public void setApellido(String apellido) {
	Apellido = apellido;
}
public String getTelefono() {
	return Telefono;
}
public void setTelefono(String telefono) {
	Telefono = telefono;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
private String Apellido;
private String Telefono;
private String Email;
}
